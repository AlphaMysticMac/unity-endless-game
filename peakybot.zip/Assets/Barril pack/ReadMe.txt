Metal Barrel FREE 3d model

INCLUDE :

1 .fbx model : 552 polys
2 .jpg Diffuse map 1024x1024
3 .jpg Normal map 1024x1024



Contact and Support https://sl3dcreation.wordpress.com/